class NoSongSelectedError(Exception):
    pass